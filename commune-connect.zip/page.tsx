import ContactForm from "@/components/contact-form"

export default function ContactPage() {
  return (
    <div className="container mx-auto py-12">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8">Get in Touch</h1>
        <p className="text-center text-muted-foreground mb-8">
          Have questions about Commune Connect? Want to organize an event or create a community? We're here to help!
        </p>
        <ContactForm />
      </div>
    </div>
  )
}
