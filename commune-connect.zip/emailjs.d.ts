interface Window {
  emailjs: {
    init: (userId: string) => Promise<void>
    send: (
      serviceId: string,
      templateId: string,
      templateParams: Record<string, unknown>,
      userId?: string,
    ) => Promise<{ status: number; text: string }>
  }
}
