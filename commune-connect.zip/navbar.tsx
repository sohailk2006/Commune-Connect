import Link from "next/link"

export default function Navbar() {
  return (
    <nav className="flex items-center justify-between p-4">
      <Link href="/" className="flex items-center">
        <span className="text-xl font-bold">Commune Connect</span>
      </Link>
      <div className="flex items-center gap-4">
        <Link href="/events" className="hover:underline">
          Events
        </Link>
        <Link href="/categories" className="hover:underline">
          Categories
        </Link>
        <Link href="/communities" className="hover:underline">
          Communities
        </Link>
        <Link href="/about" className="hover:underline">
          About
        </Link>
        <Link href="/contact" className="hover:underline">
          Contact
        </Link>
        <Link href="/login" className="hover:underline">
          Log in
        </Link>
        <Link href="/signup" className="bg-black text-white px-4 py-2 rounded-md">
          Sign up
        </Link>
      </div>
    </nav>
  )
}
